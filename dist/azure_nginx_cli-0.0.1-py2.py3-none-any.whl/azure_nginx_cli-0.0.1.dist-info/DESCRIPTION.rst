An Azure Nginx CLI extension that allows the provisioning of self reliant nginx clusters


